import { MessagingDashboard } from '@/components/messaging-dashboard'

export default function DashboardPage() {
  return <MessagingDashboard />
}
