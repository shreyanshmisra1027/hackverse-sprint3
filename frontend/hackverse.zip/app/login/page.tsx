import { LoginForm } from '@/components/auth-flow'

export default function LoginPage() { return <LoginForm /> }
