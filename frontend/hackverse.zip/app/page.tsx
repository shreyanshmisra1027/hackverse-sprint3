import { InevitableLanding } from '@/components/inevitable-landing'

export default function Home() {
  return <InevitableLanding />
}
