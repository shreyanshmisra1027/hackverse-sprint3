import { SignupForm } from '@/components/auth-flow'

export default function SignupPage() { return <SignupForm /> }
